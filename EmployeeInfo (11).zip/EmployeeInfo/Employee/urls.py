from django.urls import path
from . import views

urlpatterns = [
    path('', views.employee_list, name='home'),
    path('add/', views.add, name='add'),
    path('fulldetail/<int:pk>/', views.fulldetail, name='fulldetail'),
    path('delete/<int:pk>/', views.delete, name='delete'),
    path('update/<int:pk>/', views.update, name='update'),
    path('Search/', views.Searchbar, name='Search'),
]
