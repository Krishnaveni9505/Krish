from django.shortcuts import render, redirect, get_object_or_404
from .models import EmployeeInfo, Salary, Leaves, PtAmount, ProcessedSalary
from .forms import EmployeeInfoForm, SalaryForm, LeavesForm, PtAmountForm
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# ✅ Home view - paginated employee list
def employee_list(request):  # ✅ Correct function name
    data = EmployeeInfo.objects.all()
    paginator = Paginator(data, 2)

    page_num = request.GET.get('page')
    try:
        data = paginator.page(page_num)
    except PageNotAnInteger:
        data = paginator.page(1)
    except EmptyPage:
        data = paginator.page(paginator.num_pages)

    return render(request, 'show.html', {'data': data})

def fulldetail(request, pk):
    # Get employee or 404
    employee = get_object_or_404(EmployeeInfo, pk=pk)

    # Safely get related data (may be None if not entered)
    salary = Salary.objects.filter(Eid=pk).first()
    leaves = Leaves.objects.filter(Eid=pk).first()
    pt = PtAmount.objects.filter(Eid=pk).first()
    processed_salary = ProcessedSalary.objects.filter(Eid=pk).first()

    context = {
        'data': employee,
        'Salary': Salary,
        'Leaves': Leaves,
        'PtAmount': PtAmount,
        'ProcessedSalary': ProcessedSalary
    }

    return render(request, 'fulldetail.html', context)

def add(request):
    if request.method == 'POST':
        emp_form = EmployeeInfoForm(request.POST, request.FILES)
        sal_form = SalaryForm(request.POST)
        leaves_form = LeavesForm(request.POST)
        pt_form = PtAmountForm(request.POST)

        if all([emp_form.is_valid(), sal_form.is_valid(), leaves_form.is_valid(), pt_form.is_valid()]):
            employee = emp_form.save()
            sal = sal_form.save(commit=False)
            sal.Eid = employee
            sal.save()

            leaves = leaves_form.save(commit=False)
            leaves.Eid = employee
            leaves.save()

            pt = pt_form.save(commit=False)
            pt.Eid = employee
            pt.save()

            return redirect('home')
    else:
        emp_form = EmployeeInfoForm()
        sal_form = SalaryForm()
        leaves_form = LeavesForm()
        pt_form = PtAmountForm()

    return render(request, 'add.html', {
        'emp_form': emp_form,
        'sal_form': sal_form,
        'leaves_form': leaves_form,
        'pt_form': pt_form
    })

def update(request, pk):
    employee = get_object_or_404(EmployeeInfo, id=pk)

    # Assuming Eid is a unique field (e.g., CharField), not a ForeignKey
    salary = Salary.objects.filter(Eid=employee.Eid).first()
    leaves = Leaves.objects.filter(Eid=employee.Eid).first()
    pt = PtAmount.objects.filter(Eid=employee.Eid).first()

    if request.method == 'POST':
        emp_form = EmployeeInfoForm(request.POST, request.FILES, instance=employee)
        sal_form = SalaryForm(request.POST, instance=salary)
        leaves_form = LeavesForm(request.POST, instance=leaves)
        pt_form = PtAmountForm(request.POST, instance=pt)

        if emp_form.is_valid() and sal_form.is_valid() and leaves_form.is_valid() and pt_form.is_valid():
            emp_form.save()
            sal_form.save()
            leaves_form.save()
            pt_form.save()
            ProcessedSalary.objects.get_or_create(Eid=employee.Eid)
            return redirect('home')  # ✅ Corrected indentation

    else:
        emp_form = EmployeeInfoForm(instance=employee)
        sal_form = SalaryForm(instance=salary)
        leaves_form = LeavesForm(instance=leaves)
        pt_form = PtAmountForm(instance=pt)

    context = {
        'emp_form': emp_form,
        'sal_form': sal_form,
        'leaves_form': leaves_form,
        'pt_form': pt_form,
    }
    return render(request, 'update.html', context)
def delete(request, pk):
    employee = get_object_or_404(EmployeeInfo, id=pk)
    Salary.objects.filter(Eid=employee).delete()
    Leaves.objects.filter(Eid=employee).delete()
    PtAmount.objects.filter(Eid=employee).delete()
    ProcessedSalary.objects.filter(Eid=employee).delete()
    employee.delete()
    return redirect('home')


def Searchbar(request):
    employee = []  # Define an empty list by default

    if request.method == "GET":
        query = request.GET.get('query')
        if query:
            employee = EmployeeInfo.objects.filter(Name__icontains=query)
            if not employee:
                print("No employee found to show in the database")
        else:
            print("No query entered")

    return render(request, 'Searchbar.html', {'employee': employee})