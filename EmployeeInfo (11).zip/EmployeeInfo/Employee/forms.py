from django import forms
from .models import EmployeeInfo, Salary, Leaves, PtAmount, ProcessedSalary
class EmployeeInfoForm(forms.ModelForm):
    class Meta:
        model = EmployeeInfo
        fields = '__all__'
        widgets = {
            'Eid': forms.NumberInput(attrs={'class': 'form-control'}),
            'Name': forms.TextInput(attrs={'class': 'form-control'}),
            'Phone': forms.NumberInput(attrs={'class': 'form-control'}),
            'Email': forms.EmailInput(attrs={'class': 'form-control'}),
            'Dept': forms.TextInput(attrs={'class': 'form-control'}),
            'Experience': forms.NumberInput(attrs={'class': 'form-control'}),
            'Address': forms.TextInput(attrs={'class': 'form-control'}),
            'Education': forms.TextInput(attrs={'class': 'form-control'}),


        }


class SalaryForm(forms.ModelForm):
    class Meta:
        model = Salary
        fields = '__all__'
        widgets = {
            'jan_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'feb_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'mar_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'apr_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'may_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'jun_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'jul_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'aug_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'sep_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'oct_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'nov_sal': forms.NumberInput(attrs={'class': 'form-control'}),
            'dec_sal': forms.NumberInput(attrs={'class': 'form-control'}),

        }

class LeavesForm(forms.ModelForm):
    class Meta:
        model = Leaves
        fields = '__all__'
        widgets = {
            'jan_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'feb_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'mar_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'apr_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'may_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'jun_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'jul_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'aug_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'sep_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'oct_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'nov_lev': forms.NumberInput(attrs={'class': 'form-control'}),
            'dec_lev': forms.NumberInput(attrs={'class': 'form-control'}),

        }

class PtAmountForm(forms.ModelForm):
    class Meta:
        model = PtAmount
        fields = '__all__'
        widgets = {
            'jan_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'feb_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'mar_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'apr_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'may_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'jun_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'jul_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'aug_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'sep_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'oct_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'nov_pt': forms.NumberInput(attrs={'class': 'form-control'}),
            'dec_pt': forms.NumberInput(attrs={'class': 'form-control'}),

        }

class ProcessedForm(forms.ModelForm):
    class Meta:
        model = ProcessedSalary
        fields = '__all__'
        widgets = {
            'jan_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'feb_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'mar_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'apr_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'may_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'jun_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'jul_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'aug_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'sep_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'oct_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'nov_ps': forms.NumberInput(attrs={'class': 'form-control'}),
            'dec_ps': forms.NumberInput(attrs={'class': 'form-control'}),

        }
