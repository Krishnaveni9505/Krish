from django.db import models

class EmployeeInfo(models.Model):
    Eid = models.IntegerField(unique=True)  # Mark as unique since it's used as key
    Name = models.CharField(max_length=100)
    Phone = models.CharField(max_length=15)
    Email = models.EmailField()
    Dept = models.CharField(max_length=100)
    Address = models.CharField(max_length=255)
    Experience = models.FloatField()
    Education = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.Name} ({self.Eid})"


class Salary(models.Model):
    Eid = models.CharField(max_length=20)  # Should match EmployeeInfo.Eid
    jan_sal = models.IntegerField(default=0)
    feb_sal = models.IntegerField(default=0)
    mar_sal = models.IntegerField(default=0)
    apr_sal = models.IntegerField(default=0)
    may_sal = models.IntegerField(default=0)
    jun_sal = models.IntegerField(default=0)
    jul_sal = models.IntegerField(default=0)
    aug_sal = models.IntegerField(default=0)
    sep_sal = models.IntegerField(default=0)
    oct_sal = models.IntegerField(default=0)
    nov_sal = models.IntegerField(default=0)
    dec_sal = models.IntegerField(default=0)

    @property
    def total_sal(self):
        return sum([
            self.jan_sal, self.feb_sal, self.mar_sal, self.apr_sal,
            self.may_sal, self.jun_sal, self.jul_sal, self.aug_sal,
            self.sep_sal, self.oct_sal, self.nov_sal, self.dec_sal
        ])

    def __str__(self):
        return f"Salary for {self.Eid}"


class Leaves(models.Model):
    Eid = models.CharField(max_length=30)
    jan_lev = models.FloatField(default=0)
    feb_lev = models.FloatField(default=0)
    mar_lev = models.FloatField(default=0)
    apr_lev = models.FloatField(default=0)
    may_lev = models.FloatField(default=0)
    jun_lev = models.FloatField(default=0)
    jul_lev = models.FloatField(default=0)
    aug_lev = models.FloatField(default=0)
    sep_lev = models.FloatField(default=0)
    oct_lev = models.FloatField(default=0)
    nov_lev = models.FloatField(default=0)
    dec_lev = models.FloatField(default=0)

    @property
    def total_lev(self):
        return sum([
            self.jan_lev, self.feb_lev, self.mar_lev, self.apr_lev,
            self.may_lev, self.jun_lev, self.jul_lev, self.aug_lev,
            self.sep_lev, self.oct_lev, self.nov_lev, self.dec_lev
        ])

    def __str__(self):
        return f"Leaves for {self.Eid}"


class PtAmount(models.Model):
    Eid = models.CharField(max_length=30)
    jan_pt = models.FloatField(default=0)
    feb_pt = models.FloatField(default=0)
    mar_pt = models.FloatField(default=0)
    apr_pt = models.FloatField(default=0)
    may_pt = models.FloatField(default=0)
    jun_pt = models.FloatField(default=0)
    jul_pt = models.FloatField(default=0)
    aug_pt = models.FloatField(default=0)
    sep_pt = models.FloatField(default=0)
    oct_pt = models.FloatField(default=0)
    nov_pt = models.FloatField(default=0)
    dec_pt = models.FloatField(default=0)

    def total_pt(self):
        return sum([
            self.jan_pt, self.feb_pt, self.mar_pt, self.apr_pt,
            self.may_pt, self.jun_pt, self.jul_pt, self.aug_pt,
            self.sep_pt, self.oct_pt, self.nov_pt, self.dec_pt
        ])

    def __str__(self):
        return f"PTAmount for {self.Eid}"


class ProcessedSalary(models.Model):
    Eid = models.CharField(max_length=30)
    jan_ps = models.FloatField(default=0)
    feb_ps = models.FloatField(default=0)
    mar_ps = models.FloatField(default=0)
    apr_ps = models.FloatField(default=0)
    may_ps = models.FloatField(default=0)
    jun_ps = models.FloatField(default=0)
    jul_ps = models.FloatField(default=0)
    aug_ps = models.FloatField(default=0)
    sep_ps = models.FloatField(default=0)
    oct_ps = models.FloatField(default=0)
    nov_ps = models.FloatField(default=0)
    dec_ps = models.FloatField(default=0)
    total_ps = models.FloatField(default=0)

    def save(self, *args, **kwargs):
        salary = Salary.objects.filter(Eid=self.Eid).first()
        leaves = Leaves.objects.filter(Eid=self.Eid).first()
        pt = PtAmount.objects.filter(Eid=self.Eid).first()

        if not all([salary, leaves, pt]):
            raise ValueError(f"Missing related data for Eid {self.Eid}.")

        working_days = {
            'jan': 30, 'feb': 28, 'mar': 30, 'apr': 30, 'may': 30, 'jun': 30,
            'jul': 30, 'aug': 31, 'sep': 30, 'oct': 30, 'nov': 30, 'dec': 30
        }

        total = 0
        for month in working_days:
            sal = getattr(salary, f"{month}_sal", 0)
            leave = getattr(leaves, f"{month}_lev", 0)
            deduction = getattr(pt, f"{month}_pt", 0)

            # Prevent division by zero
            days = working_days[month] or 30

            net = sal - (sal * leave / days) - deduction
            net = round(net, 2)
            setattr(self, f"{month}_ps", net)
            total += net

        self.total_ps = round(total, 2)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"ProcessedSalary for {self.Eid}"
