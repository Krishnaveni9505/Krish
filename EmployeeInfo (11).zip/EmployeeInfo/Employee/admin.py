from django.contrib import admin
from .models import EmployeeInfo, Salary, Leaves, PtAmount, ProcessedSalary

# Admin for EmployeeInfo
@admin.register(EmployeeInfo)
class EmployeeInfoAdmin(admin.ModelAdmin):
    list_display = ('Eid', 'Name', 'Dept', 'Email', 'Phone', 'Experience', 'Education')
    search_fields = ('Eid', 'Name', 'Dept', 'Email')
    list_filter = ('Dept', 'Education')


@admin.register(Salary)
class SalaryAdmin(admin.ModelAdmin):
    list_display = ('Eid', 'jan_sal', 'feb_sal', 'mar_sal', 'apr_sal', 'may_sal', 'jun_sal',
                    'jul_sal', 'aug_sal', 'sep_sal', 'oct_sal', 'nov_sal', 'dec_sal')
    search_fields = ('Eid',)
    list_filter = ('Eid',)


@admin.register(Leaves)
class LeavesAdmin(admin.ModelAdmin):
    list_display = ('Eid', 'jan_lev', 'feb_lev', 'mar_lev', 'apr_lev', 'may_lev', 'jun_lev',
                    'jul_lev', 'aug_lev', 'sep_lev', 'oct_lev', 'nov_lev', 'dec_lev')
    search_fields = ('Eid',)
    list_filter = ('Eid',)


@admin.register(PtAmount)
class PtAmountAdmin(admin.ModelAdmin):
    list_display = ('Eid', 'jan_pt', 'feb_pt', 'mar_pt', 'apr_pt', 'may_pt', 'jun_pt',
                    'jul_pt', 'aug_pt', 'sep_pt', 'oct_pt', 'nov_pt', 'dec_pt')
    search_fields = ('Eid',)
    list_filter = ('Eid',)


@admin.register(ProcessedSalary)
class ProcessedSalaryAdmin(admin.ModelAdmin):
    list_display = ('Eid', 'jan_ps', 'feb_ps', 'mar_ps', 'apr_ps', 'may_ps', 'jun_ps',
                    'jul_ps', 'aug_ps', 'sep_ps', 'oct_ps', 'nov_ps', 'dec_ps', 'total_ps')
    search_fields = ('Eid',)
    list_filter = ('Eid',)



